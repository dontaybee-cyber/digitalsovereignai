# Sovereign AI Stack

A local, privacy-first Open WebUI + Ollama + SearXNG deployment intended for offline-friendly or local-only AI use.

## Quick start

```bash
./start.sh
```

This script does the following in one step:
- creates a local `.env` file from `.env.example` if needed
- validates Docker and Compose
- generates secure keys where needed
- creates persistent storage directories
- starts the stack
- waits for Ollama to come up
- downloads the default model (`llama3.1`)

## Health checks

After startup, verify the services are up:

```bash
docker compose ps
curl -fsS http://127.0.0.1:3000 >/dev/null && echo "Open WebUI is healthy"
docker exec sovereign_ollama ollama list
```

## Access

Open WebUI: http://127.0.0.1:3000

## Important notes

- Open WebUI is bound only to `127.0.0.1` for local access.
- Ollama and SearXNG stay on the private Docker network.
- The host data directory is persisted at `./data/webui`.
- Copy `.env.example` to `.env` and replace the secret placeholders before first use.

## Troubleshooting

If Open WebUI does not respond:

```bash
docker compose logs --tail=200 open-webui
```

If Ollama is not ready:

```bash
docker compose logs --tail=200 ollama
```

If you need to reset the stack:

```bash
docker compose down -v
docker volume rm sovereign-ai_ollama_storage 2>/dev/null || true
./start.sh
```
