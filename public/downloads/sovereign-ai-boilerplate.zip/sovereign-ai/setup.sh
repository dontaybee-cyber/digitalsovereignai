#!/usr/bin/env bash
set -Eeuo pipefail

echo "=================================================="
echo "   Sovereign AI Deployment Setup"
echo "=================================================="

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: Docker is not installed or not on PATH."
  exit 1
fi

if ! docker compose version >/dev/null 2>&1; then
  echo "ERROR: Docker Compose plugin not found."
  exit 1
fi

if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    cp .env.example .env
    echo "[+] Created .env from .env.example"
  else
    echo "ERROR: .env is missing and .env.example was not found."
    exit 1
  fi
fi

set -a
source .env
set +a

if [ -z "${WEBUI_SECRET_KEY:-}" ] || [ "${WEBUI_SECRET_KEY}" = "replace_with_a_secure_random_value" ]; then
  export WEBUI_SECRET_KEY="$(openssl rand -hex 32)"
  if grep -q '^WEBUI_SECRET_KEY=' .env; then
    sed -i "s|^WEBUI_SECRET_KEY=.*|WEBUI_SECRET_KEY=${WEBUI_SECRET_KEY}|" .env
  else
    printf '\nWEBUI_SECRET_KEY=%s\n' "${WEBUI_SECRET_KEY}" >> .env
  fi
  echo "[+] Generated a secure Open WebUI secret key."
fi

if grep -q "GENERATE_RANDOM_KEY_DURING_SETUP" ./searxng/settings.yml 2>/dev/null; then
  SEARX_KEY="$(openssl rand -hex 32)"
  sed -i "s/GENERATE_RANDOM_KEY_DURING_SETUP/${SEARX_KEY}/g" ./searxng/settings.yml
  echo "[+] Generated SearXNG secret key."
else
  echo "[i] SearXNG secret key already set, skipping."
fi

mkdir -p ./data/webui
chmod 700 ./data ./data/webui

echo "[1/3] Starting Docker containers..."
docker compose up -d --remove-orphans

echo "[2/3] Waiting for Ollama to become ready..."
ATTEMPTS=0
MAX_ATTEMPTS=60
until docker exec sovereign_ollama ollama list >/dev/null 2>&1; do
  ATTEMPTS=$((ATTEMPTS + 1))
  if [ "$ATTEMPTS" -ge "$MAX_ATTEMPTS" ]; then
    echo "ERROR: Ollama did not become ready in time. Check 'docker logs sovereign_ollama'."
    exit 1
  fi
  sleep 2
done

echo "[3/3] Pulling default foundation model..."
docker exec sovereign_ollama ollama pull llama3.1

echo "=================================================="
echo " Setup complete."
echo " Access the UI at: http://127.0.0.1:3000"
echo "=================================================="
