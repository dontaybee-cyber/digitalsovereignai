#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    cp .env.example .env
    echo "[+] Created .env from .env.example"
  else
    echo "ERROR: .env.example was not found."
    exit 1
  fi
fi

if [ ! -x ./setup.sh ]; then
  chmod +x ./setup.sh
fi

./setup.sh

echo ""
echo "=================================================="
echo " Health checks"
echo "=================================================="
if curl -fsS http://127.0.0.1:3000 >/dev/null 2>&1; then
  echo "[OK] Open WebUI is responding at http://127.0.0.1:3000"
else
  echo "[WARN] Open WebUI check failed; it may still be starting up."
fi

echo "Run: docker compose ps"
