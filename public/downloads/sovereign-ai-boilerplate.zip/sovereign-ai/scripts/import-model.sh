#!/usr/bin/env bash
# Build the "sovereign" assistant model from models/Modelfile.
#
# Offline by default: the base model must already be present in ./data/ollama
# (it travels with the project folder once vendored). Pass --allow-network to
# permit the single one-time `ollama pull` of the base model.
#
# Usage: scripts/import-model.sh [--allow-network]

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib.sh"
load_env

ALLOW_NETWORK=0
[ "${1:-}" = "--allow-network" ] && ALLOW_NETWORK=1
[ "${SOVEREIGN_OFFLINE:-1}" = "0" ] && ALLOW_NETWORK=1

require_docker

BASE_MODEL="${BASE_MODEL:-llama3.1}"
BUILT_MODEL="sovereign"

# --- Make sure Ollama is up ---------------------------------------------------
if ! docker exec sovereign_ollama ollama list >/dev/null 2>&1; then
  log "Starting Ollama container..."
  ( cd "$SOVEREIGN_ROOT" && docker compose up -d ollama )
  wait_for_ollama
fi

# --- Ensure the base model exists locally -------------------------------------
base_present() {
  docker exec sovereign_ollama ollama list 2>/dev/null | awk '{print $1}' \
    | grep -qx "$BASE_MODEL"
}

if base_present; then
  ok "Base model present: $BASE_MODEL"
else
  if [ "$ALLOW_NETWORK" -eq 1 ]; then
    log "Base model '$BASE_MODEL' not found — pulling it once (network allowed)."
    docker exec sovereign_ollama ollama pull "$BASE_MODEL"
  else
    die "Base model '$BASE_MODEL' is not present and the stack is offline.
    To go online for the one-time fetch:  scripts/import-model.sh --allow-network
    Or copy a fully-populated ./data/ollama from an online machine."
  fi
fi

# --- Render the persona Modelfile ---------------------------------------------
bash "$SOVEREIGN_ROOT/scripts/render-modelfile.sh"

# --- Build the sovereign model inside the container ---------------------------
log "Building '$BUILT_MODEL' from models/Modelfile"
docker cp "$SOVEREIGN_ROOT/models/Modelfile" sovereign_ollama:/tmp/sovereign.Modelfile
docker exec sovereign_ollama ollama create "$BUILT_MODEL" -f /tmp/sovereign.Modelfile
docker exec sovereign_ollama rm -f /tmp/sovereign.Modelfile >/dev/null 2>&1 || true

ok "Assistant '$BUILT_MODEL' is ready."
