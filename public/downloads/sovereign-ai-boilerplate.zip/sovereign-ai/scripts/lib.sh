#!/usr/bin/env bash
# Shared helpers for the Sovereign stack scripts.
# Source this file:  source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

set -Eeuo pipefail

# --- Locate the project root (the directory that holds docker-compose.yml) ---
lib_find_root() {
  local dir
  dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
  printf '%s' "$dir"
}

SOVEREIGN_ROOT="$(lib_find_root)"
export SOVEREIGN_ROOT

# --- Pretty logging ----------------------------------------------------------
_c_reset='\033[0m'; _c_dim='\033[2m'; _c_red='\033[31m'; _c_green='\033[32m'
_c_yellow='\033[33m'; _c_blue='\033[34m'

log()  { printf "${_c_blue}==>${_c_reset} %s\n" "$*"; }
info() { printf "${_c_dim}    %s${_c_reset}\n" "$*"; }
ok()   { printf "${_c_green}[ok]${_c_reset} %s\n" "$*"; }
warn() { printf "${_c_yellow}[warn]${_c_reset} %s\n" "$*" >&2; }
die()  { printf "${_c_red}[error]${_c_reset} %s\n" "$*" >&2; exit 1; }

# --- Environment -------------------------------------------------------------
# Load .env into the current shell without clobbering already-set variables.
load_env() {
  local env_file="${1:-$SOVEREIGN_ROOT/.env}"
  [ -f "$env_file" ] || return 0
  set -a
  # shellcheck disable=SC1090
  . "$env_file"
  set +a
}

# Read a single key from .env (or empty if absent), ignoring comments.
env_get() {
  local key="$1" env_file="${2:-$SOVEREIGN_ROOT/.env}"
  [ -f "$env_file" ] || return 0
  # Match the first line that starts with KEY=
  sed -n "s/^${key}=//p" "$env_file" | head -n1
}

# Set KEY=value in .env, replacing an existing line or appending a new one.
env_set() {
  local key="$1" value="$2" env_file="${3:-$SOVEREIGN_ROOT/.env}"
  [ -f "$env_file" ] || touch "$env_file"
  if grep -q "^${key}=" "$env_file"; then
    # Use a temp file to stay portable across GNU/BSD sed.
    local tmp; tmp="$(mktemp)"
    awk -v k="$key" -v v="$value" '
      BEGIN { done=0 }
      $0 ~ "^"k"=" { print k"="v; done=1; next }
      { print }
      END { if (!done) print k"="v }
    ' "$env_file" > "$tmp"
    mv "$tmp" "$env_file"
  else
    printf '%s=%s\n' "$key" "$value" >> "$env_file"
  fi
}

# --- Preconditions -----------------------------------------------------------
require_docker() {
  command -v docker >/dev/null 2>&1 || \
    die "Docker is not installed or not on PATH. Install Docker Desktop first."
  docker compose version >/dev/null 2>&1 || \
    die "The Docker Compose plugin is required (docker compose)."
}

# Wait until Ollama inside the running stack answers `ollama list`.
wait_for_ollama() {
  local max="${1:-60}" i=0
  while ! docker exec sovereign_ollama ollama list >/dev/null 2>&1; do
    i=$((i + 1))
    if [ "$i" -ge "$max" ]; then
      die "Ollama did not become ready within $((max * 2))s. Check: docker logs sovereign_ollama"
    fi
    sleep 2
  done
}

# Generate a 32-byte hex secret. Prefers openssl, falls back to /dev/urandom.
gen_secret() {
  if command -v openssl >/dev/null 2>&1; then
    openssl rand -hex 32
  else
    head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n'
  fi
}
