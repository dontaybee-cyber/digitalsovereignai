#!/usr/bin/env bash
# Render models/Modelfile.template into models/Modelfile, using the current
# BASE_MODEL and SOVEREIGN_NAME from .env.
#
# Usage: scripts/render-modelfile.sh

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib.sh"
load_env

MODELS_DIR="$SOVEREIGN_ROOT/models"
TEMPLATE="$MODELS_DIR/Modelfile.template"
OUT="$MODELS_DIR/Modelfile"

[ -f "$TEMPLATE" ] || die "Missing template: $TEMPLATE"

BASE_MODEL="${BASE_MODEL:-llama3.1}"
SOVEREIGN_NAME="${SOVEREIGN_NAME:-}"

# Choose the name block.
if [ -n "$SOVEREIGN_NAME" ]; then
  BLOCK="$MODELS_DIR/name-block.named.txt"
else
  BLOCK="$MODELS_DIR/name-block.unnamed.txt"
fi
[ -f "$BLOCK" ] || die "Missing name block: $BLOCK"

TMP1="$(mktemp)"
TMP2="$(mktemp)"
trap 'rm -f "$TMP1" "$TMP2"' EXIT

# 1) Swap the __NAME_BLOCK__ line for a unique marker we can splice on.
awk '/__NAME_BLOCK__/ { print "___NAME_BLOCK_MARKER___"; next } { print }' \
  "$TEMPLATE" > "$TMP1"

# 2) Replace the marker line with the block file's contents.
sed "/___NAME_BLOCK_MARKER___/{
  r $BLOCK
  d
}" "$TMP1" > "$TMP2"

# 3) Substitute the base model and the name.
sed -e "s|__BASE_MODEL__|$BASE_MODEL|g" \
    -e "s|__SOVEREIGN_NAME__|$SOVEREIGN_NAME|g" \
    "$TMP2" > "$OUT"

if [ -n "$SOVEREIGN_NAME" ]; then
  ok "Rendered Modelfile for '$SOVEREIGN_NAME' (base: $BASE_MODEL)"
else
  ok "Rendered Modelfile (unnamed, base: $BASE_MODEL)"
fi
info "-> models/Modelfile"
