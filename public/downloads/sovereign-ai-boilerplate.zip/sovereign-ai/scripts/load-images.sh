#!/usr/bin/env bash
# Load previously vendored container images from ./images/*.tar — fully offline.
#
# Run this on an air-gapped machine after copying the project folder over.
# Usage: scripts/load-images.sh

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib.sh"

require_docker

IMAGES_DIR="$SOVEREIGN_ROOT/images"
[ -d "$IMAGES_DIR" ] || die "No ./images directory. Run scripts/vendor-images.sh on an online machine first."

shopt -s nullglob
TARS=("$IMAGES_DIR"/*.tar)
shopt -u nullglob

[ "${#TARS[@]}" -gt 0 ] || die "No image tarballs found in $IMAGES_DIR."

log "Loading ${#TARS[@]} image tarball(s)"
for tar in "${TARS[@]}"; do
  log "loading $(basename "$tar")"
  docker load -i "$tar"
done

# Confirm every image compose expects is now present locally.
COMPOSE_FILE="$SOVEREIGN_ROOT/docker-compose.yml"
MISSING=0
while read -r img; do
  [ -n "$img" ] || continue
  if docker image inspect "$img" >/dev/null 2>&1; then
    ok "present: $img"
  else
    warn "missing: $img (commit/vendor it before going offline)"
    MISSING=$((MISSING + 1))
  fi
done < <(grep -E '^[[:space:]]*image:' "$COMPOSE_FILE" | awk '{print $2}' | sort -u)

if [ "$MISSING" -gt 0 ]; then
  die "$MISSING image(s) still missing. The stack cannot start offline."
fi

ok "All required images are present locally."
