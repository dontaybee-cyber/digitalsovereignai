#!/usr/bin/env bash
# Vendor the stack's container images into ./images/*.tar for offline use.
#
# This is the ONE script that may reach a registry. Run it once on a machine
# with internet, then copy the whole project folder (including ./images) to any
# air-gapped machine and run scripts/load-images.sh there.
#
# Usage: scripts/vendor-images.sh [--force]

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib.sh"

FORCE=0
[ "${1:-}" = "--force" ] && FORCE=1

require_docker

IMAGES_DIR="$SOVEREIGN_ROOT/images"
mkdir -p "$IMAGES_DIR"

COMPOSE_FILE="$SOVEREIGN_ROOT/docker-compose.yml"
[ -f "$COMPOSE_FILE" ] || die "docker-compose.yml not found at $COMPOSE_FILE"

# Collect the image references straight from compose so this never drifts.
mapfile -t IMAGES < <(grep -E '^[[:space:]]*image:' "$COMPOSE_FILE" \
  | awk '{print $2}' | sort -u)

[ "${#IMAGES[@]}" -gt 0 ] || die "No images found in docker-compose.yml"

sanitize() { printf '%s' "$1" | tr '/:' '__'; }

log "Vendoring ${#IMAGES[@]} image(s) into ./images"
info "(this is the only step that uses the network)"

MANIFEST="$IMAGES_DIR/manifest.txt"
: > "$MANIFEST"

for img in "${IMAGES[@]}"; do
  tar="$IMAGES_DIR/$(sanitize "$img").tar"
  if [ -f "$tar" ] && [ "$FORCE" -ne 1 ]; then
    ok "already vendored: $(basename "$tar")  (use --force to refresh)"
  else
    log "pulling $img"
    docker pull "$img"
    log "saving  -> $(basename "$tar")"
    docker save -o "$tar" "$img"
  fi

  digest="$(docker image inspect --format '{{join .RepoDigests " "}}' "$img" 2>/dev/null || true)"
  printf '%s  %s\n' "$img" "${digest:-<no-repo-digest (locally built)>}" >> "$MANIFEST"
  if [ -n "$digest" ]; then
    info "pinned digest: $digest"
  fi
done

ok "Images vendored. Manifest: images/manifest.txt"
info "Copy this whole folder to the offline machine, then run scripts/load-images.sh"
